# listslab.py
# A collection of functions that perform various operations on sets
# represented as lists

# STUDENTS: REPLACE THIS LINE WITH A LINE CONTAINING YOUR NAMES!

def intersection(setA, setB):
    """Form the intersection of two sets.

    Args:
        setA, setB (list): lists representing sets.
    
    Returns:
        list: list representing the intersection of the two sets.
    """
    result = []
    for element in setA:
        if element in setB:
            result += [element]
    return result

#def union(setA, setB):
    """Form the union of two sets.

    Args:
        setA, setB (list): lists representing sets.
    
    Returns:
        list: list representing the union of the two sets.
    """

#def difference(setA, setB):
    """Form the difference of two sets.

    Args:
        setA, setB (list): lists representing sets.
    
    Returns:
        list: list representing the difference (setA-setB).
    """

#def isSubset(setA, setB):
    """Determine if one set is a subset of another.

    Args:
        setA, setB (list): lists representing sets.
    
    Returns:
        bool: True if setA is a subset of setB, otherwise False.
    """

#def setsEqual(setA, setB):
    """Determine if two sets are equal.

    Args:
        setA, setB (list): lists representing sets.
    
    Returns:
        bool: True if setA and setB have the same elements,
                otherwise False.
    """

#def isSet(list):
    """Determine if a list is a set (i.e, no duplicate elements).

    Args:
        list (list): a list.

    Returns:
        bool: True if the list is a set, otherwise False.
    """
