from listslab import *

# CPS121 Automatic tester for list lab

# A compiled version of this should be given to students, so they
# cannot see the source code since they will be asked to write test
# code in lab later this semester.  The order of the tests in this
# file is the same as the order in the listslab.py skeleton given to
# the students, and the tests use a test for whether a function is
# defined to facilitate use for automatic testing in the lists lab
# (where students may not yet have written all the functions.  When a
# function fails to produce the expected result, the checking code
# writes information about the failure which would not otherwise be
# printed by py.test given that the tester source is not available.

# To compile:
#   >>> import py_compile
#   >>> py_compile.compile('dotests.py', cfile='dotests.pyc')

# Author: Russell C. Bjork

# Modified - change tests for isSet to use bigger integers to catch
# a student mistake in code

# Modified 2019-10-15 <jonathan.senning@gordon.edu>
# Changed list for first isSet() test is it is not a set

# Modified 2020-10-17 <jonathan.senning@gordon.edu>
# Reformatted to use spaces rather than tabs and update to Python 3

def test_intersection():
    checkExistence("intersection")
    checkOperation(intersection, [10, 2, 31], [31, 2, 10], [10, 2, 31])
    checkOperation(intersection, [ 1, 12, 3 ], [ 12, 3, 1 ], [1, 12, 3])
    checkOperation(intersection, [], [], [])
    checkOperation(intersection, [11, 2, 4, 13], [2, 13, 11], [11, 2, 13])
    checkOperation(intersection, [1, 20, 3], [20, 3, 4, 1], [1, 20, 3])
    checkOperation(intersection, [], [1], [])
    checkOperation(intersection, [1], [], [])

# TODO: make data values more varied than 1, 2, 3 below (as above)
#   then retest, and put compiled version on server for lab

def test_union():
    checkExistence("union")
    checkOperation(union, [1, 2, 3], [3, 2, 1], [1, 2, 3])
    checkOperation(union, [ 1, 2, 3 ], [ 2, 3, 1 ], [1, 2, 3])
    checkOperation(union, [], [], [])
    checkOperation(union, [1, 2, 4, 3], [2, 3, 1], [1, 2, 3, 4])
    checkOperation(union, [1, 2, 3], [2, 3, 4, 1], [1, 2, 3, 4])
    checkOperation(union, [], [1], [1])
    checkOperation(union, [1], [], [1])

def test_difference():
    checkExistence("difference")
    checkOperation(difference, [1, 2, 3], [3, 2, 1], [])
    checkOperation(difference, [ 1, 2, 3 ], [ 2, 3, 1 ], [])
    checkOperation(difference, [], [], [])
    checkOperation(difference, [1, 2, 4, 3], [2, 3, 1], [4])
    checkOperation(difference, [1, 2, 3], [2, 3, 4, 1], [])
    checkOperation(difference, [], [1], [])
    checkOperation(difference, [1], [], [1])

def test_isSubset():
    checkExistence("isSubset")
    checkOperationBoolean2(isSubset, [1, 2, 3], [3, 2, 1], True)
    checkOperationBoolean2(isSubset, [ 1, 2, 3 ], [ 2, 3, 1 ], True)
    checkOperationBoolean2(isSubset, [], [], True)
    checkOperationBoolean2(isSubset, [1, 2, 4, 3], [2, 3, 1], False)
    checkOperationBoolean2(isSubset, [1, 2, 3], [2, 3, 4, 1], True)
    checkOperationBoolean2(isSubset, [], [1], True)
    checkOperationBoolean2(isSubset, [1], [], False)

def test_setsEqual():
    checkExistence("setsEqual")
    checkOperationBoolean2(setsEqual, [ 1, 2, 3 ], [ 1, 2, 3 ], True)
    checkOperationBoolean2(setsEqual, [ 1, 2, 3 ], [ 2, 3, 1 ], True)
    checkOperationBoolean2(setsEqual, [], [], True)
    checkOperationBoolean2(setsEqual, [1, 2, 4, 3], [2, 3, 1], False)
    checkOperationBoolean2(setsEqual, [1, 2, 3], [2, 3, 4, 1], False)
    checkOperationBoolean2(setsEqual, [], [1], False)
    checkOperationBoolean2(setsEqual, [1], [], False)

def test_isSet():
    checkExistence("isSet")
    checkOperationBoolean1(isSet, [10, 11, 10], False)
    checkOperationBoolean1(isSet, [11, 12, 13], True)
    checkOperationBoolean1(isSet, [11, 12, 13, 12, 14], False)
    checkOperationBoolean1(isSet, [], True)

def checkExistence(operationName):
    """Check to see if an operation exists.

    Args:
        operationNane (str): the operation's names as a string.

    Returns:
        bool: True if an operation of operationName exists, else
              raises an AssertionException with an appropriate message.
    """
    try:
        globals()[operationName]
    except KeyError:
        raise AssertionError("Tests of " + operationName + " skipped")
    else:
        return True

def checkOperation(operation, setA, setB, expected):
    """Check an operation applied to two sets that returns a set.

    Args:
        operation (function): the set operation to apply.
        setA, setB (list): the two sets input to the operation.
        expected (list): the expected result.
    
    Returns:
        bool: True if the result of applying the operation to setA and setB
            is expected else raises an AssertionException with an
            appropriate message.
    """
    result = operation(setA, setB)
    if len(result) != len(expected):
        raise AssertionError(f"{operation.__name__}({setA}, {setB}) " + \
                             f"was {result} when {expected} was expected")
    for element in result:
        if not element in expected:
            raise AssertionError(f"{operation.__name__}({setA}, {setB}) " + \
                                 f"was {result} when {expected} was expected")
    for element in expected:
        if not element in result:
            raise AssertionError(f"{operation.__name__}({setA}, {setB}) " + \
                                 f"was {result} when {expected} was expected")
    return True

def checkOperationBoolean2(operation, setA, setB, expected):
    """Check an operation applied to two sets that returns a boolean.

    Args:
        operation (function): the set operation to apply.
        setA, setB (list): the two sets input to the operation.
        expected (bool): the expected result.

    Returns:
        bool: True if the result of applying the operation to setA and setB
            is expected else raises an AssertionException with an
            appropriate message.
    """

    result = operation(setA, setB)
    if result != expected:
        raise AssertionError(f"{operation.__name__}({setA}, {setB}) " + \
                             f"was {result} when {expected} was expected")
    else:
        return True

def checkOperationBoolean1(operation, set, expected):
    """Check an operation applied to a single set that returns a boolean

    operation - the operation
    set - the set input to the operation
    expected - the expected result
    returns True if the result of applying the operation to set is expected
     else raises an AssertionException with an appropriate message
    """
    result = operation(set)
    if result != expected:
        raise AssertionError(f"{operation.__name__}({set}) " + \
                             f"was {result} when {expected} was expected")
    else:
        return True
